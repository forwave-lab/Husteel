﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using Infragistics.Documents.Excel;
using System.Runtime.InteropServices;


namespace capture
{
    public partial class Form1 : Form
    {
        Boolean Excel_Read_Close = false;
        DataTable HeatRecord = new DataTable("HeatRecord");

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Bitmap Bitmap;
            Point StartX;
            Point StartY;
            Graphics Graphics;
            if (radioButton1.Checked == true)
            {
                Bitmap = new Bitmap(ultraChart1.Width, ultraChart1.Height);
                Graphics = Graphics.FromImage(Bitmap);

                StartX = PointToScreen(new Point(ultraChart1.Location.X, 0));
                StartY = PointToScreen(new Point(0, ultraChart1.Location.Y));
            }
            else
            {
                Bitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
                Graphics = Graphics.FromImage(Bitmap);

                StartX = PointToScreen(new Point(pictureBox1.Location.X, 0));
                StartY = PointToScreen(new Point(0, pictureBox1.Location.Y));
            }

            Graphics.CopyFromScreen(
            StartX.X,
            StartY.Y,
            0,
            0,
            new Size(Bitmap.Width, Bitmap.Height));

            //Bitmap.Save(@"test.bmp", System.Drawing.Imaging.ImageFormat.Bmp);
            Clipboard.SetImage((Image)Bitmap);
        }

        private static string FromStringToDate(string stringDate)
        {
            double date = double.Parse(stringDate);
            string sdate = DateTime.FromOADate(date).ToString("yyyy-MM-dd");
            return sdate;
        }

        private static string FromStringToTime(string stringDate)
        {
            double time = double.Parse(stringDate);
            string stime = DateTime.FromOADate(time).ToString("HH:mm:ss");
            return stime;
        }

        private void ultraButton1_Click(object sender, EventArgs e)
        {
            //List<string> ExcelList = new List<string>();

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.DefaultExt = "Excel Files";
                openFileDialog.Filter = "Excel Files |*.xls;*.xlsx";
                openFileDialog.Multiselect = false;

                string strFileDir = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                openFileDialog.InitialDirectory = strFileDir;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        if (openFileDialog.SafeFileName.LastIndexOf(".") > -1)
                        {
                            Workbook workbook = new Workbook();
                            workbook = Workbook.Load(openFileDialog.FileName);
                            
                            Worksheet worksheet = workbook.Worksheets[0];                            

                           // DataTable HeatRecord = new DataTable("HeatRecord");

                            int rowCount = 0;
                            int columnCount = 0;

                            foreach (WorksheetRow worksheetRow in worksheet.Rows)
                            {
                                if (rowCount == 0)
                                {
                                    //foreach (WorksheetCell worksheetCell in worksheetRow.Cells)
                                    //{
                                    //    string cellValue = worksheetCell.Value.ToString().Trim();
                                    //    if (cellValue == string.Empty || cellValue == "$Date")
                                    //    {
                                    //        break;
                                    //    }
                                    //    else
                                    //    {
                                    //        //DataColumn dataColumn = HeatRecord.Columns.Add();
                                    //        //dataColumn.ColumnName = cellValue;
                                    //        //dataColumn.DataType = worksheet.Rows[rowCount + 1].Cells[columnCount].Value.GetType();
                                    //    }
                                    //    //columnCount++;
                                    //}
                                }
                                else
                                {
                                    columnCount = 0;
                                    DataRow HeatRecordRow = HeatRecord.NewRow();
                                    foreach (WorksheetCell worksheetCell in worksheetRow.Cells)
                                    {
                                        if (worksheetCell.Value == null)
                                        {
                                            Excel_Read_Close = true;
                                            break;
                                        }    
                                        else
                                        {
                                            string cellValue = worksheet.Rows[rowCount].Cells[columnCount].Value.ToString().Trim();
                                            if (rowCount == 1)
                                            {
                                                DataColumn dataColumn = HeatRecord.Columns.Add();
                                                //dataColumn.DataType = worksheet.Rows[rowCount + 1].Cells[columnCount].Value.GetType();
                                                //dataColumn.ColumnName = cellValue;
                                            }

                                            if (columnCount == 0)
                                            {
                                                HeatRecordRow[columnCount] = FromStringToDate(cellValue).ToString();
                                            }
                                            else if (columnCount == 1)
                                            {
                                                HeatRecordRow[columnCount] = FromStringToTime(cellValue).ToString();
                                            }
                                            else
                                            {
                                                HeatRecordRow[columnCount] = Math.Round(double.Parse(cellValue), 2);
                                            }

                                            columnCount++;
                                        }
                                    }
                                    HeatRecord.Rows.Add(HeatRecordRow);  
                                }
                                rowCount++;
                                if (Excel_Read_Close == true)
                                {
                                    break;
                                }
                            }
                            HeatRecord.AcceptChanges();

                           // workbook.Worksheets[0].Rows[0].Cells[0].Value = 42;                            
                        }
                        else
                        {

                        }
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    ultraGrid1.DataSource = HeatRecord;
                }
            }
        }
    }
}
